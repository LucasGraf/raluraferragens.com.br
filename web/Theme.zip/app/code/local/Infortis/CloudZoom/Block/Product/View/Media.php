<?php

class Infortis_CloudZoom_Block_Product_View_Media extends Mage_Catalog_Block_Product_View_Media
{
}
